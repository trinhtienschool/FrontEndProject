const constants = {
  DIRECTION_VERTICAL: 'vertical',
  DIRECTION_HORIZONTAL: 'horizontal',
  TYPE_INTERVAL: 'interval',
  TYPE_SINGLE: 'single',
};

export { constants };
